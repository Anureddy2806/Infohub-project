use crate as pyo3;
include!("../tests/common.rs");
