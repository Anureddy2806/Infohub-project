use pyo3_build_config::PythonVersion;

pub const PY_3_9: PythonVersion = PythonVersion { major: 3, minor: 9 };
