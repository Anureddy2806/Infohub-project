fn main() {
    pyo3_build_config::print_expected_cfgs();
    pyo3_build_config::print_feature_cfgs();
}
